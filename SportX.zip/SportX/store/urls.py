from django.urls import path
from .views import *
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('',home, name='home'),
    path('login/',user_login, name='login'),
    path('register/',register, name='register'),
    path('products/',products, name='products'),
    path('product/<int:id>/', product_details, name='product_detail'),
    path('cart/',cart, name='cart'),
    path('add-to-cart/<int:product_id>/', add_to_cart, name='add_to_cart'),
    path('remove-from-cart/<int:item_id>/', remove_from_cart, name='remove_from_cart'),
    path('increase-quantity/<int:item_id>/', increase_quantity, name='increase_quantity'),
    path('decrease-quantity/<int:item_id>/', decrease_quantity, name='decrease_quantity'),
    path('wishlist/', wishlist_view, name='wishlist'),
    path('checkout/',checkout, name='checkout'),
    path('order-success/', order_success, name='order_success'),
    path('categories/',categories, name='categories'),
    path('my-orders/', my_orders, name='my_orders'),
    path('order/<int:order_id>/', order_detail_user, name='order_detail_user'),
    path('cancel-order/<int:order_id>/', cancel_order, name='cancel_order'),
    path('wishlist/', wishlist_view, name='wishlist'),
    path('wishlist/toggle/<int:product_id>/', toggle_wishlist, name='toggle_wishlist'),

    path('adminpanel/',adminpanel, name='adminpanel'),
    path('profile/', profile, name='profile'),
    path('logout/', user_logout, name='logout'),
    
    path('password_change/',
     auth_views.PasswordChangeView.as_view(
     template_name='password_change.html'),
     name='password_change'),

    path('password_change_done/',
     auth_views.PasswordChangeDoneView.as_view(
     template_name='password_change_done.html'),
     name='password_change_done'),

    path('adminpanel/products/', admin_products, name='admin_products'),
    path('adminpanel/add-product/', add_product, name='add_product'),
    path('adminpanel/edit-product/<int:id>/', edit_product, name='edit_product'),
    path('adminpanel/delete-product/<int:id>/', delete_product, name='delete_product'),
    path('adminpanel/add-category/', add_category, name='add_category'),
    path('adminpanel/edit-category/<int:id>/', edit_category, name='edit_category'),
    path('adminpanel/delete-category/<int:id>/', delete_category, name='delete_category'),
    path('adminpanel/orders/', admin_orders, name='admin_orders'),
    path('adminpanel/orders/<int:order_id>/', admin_order_detail, name='admin_order_detail'),
    path('adminpanel/users/', admin_users, name='admin_users'),
    path('adminpanel/customers/',admin_customers, name='admin_customers'),
    path('adminpanel/customers/toggle/<int:user_id>/', toggle_user_status, name='toggle_user_status'),
    path('adminpanel/settings/', admin_settings, name='admin_settings'),
]   