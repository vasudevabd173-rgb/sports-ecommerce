from django.shortcuts import render, redirect,get_object_or_404
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib.auth.models import User
from .models import UserProfile,Product, Category,Cart, CartItem,Order,OrderItem,Wishlist, WishlistItem
from django.contrib import messages



    
# Home Page
def home(request):
    if request.session.get('maintenance_mode') == 'on':
        return render(request, 'maintenance.html')
    
    products = Product.objects.all()[:4]
    return render(request, 'home.html', {'products': products})


# Login
def user_login(request):

    if request.method == 'POST':

        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:

            login(request, user)

            # Redirect based on user type
            if user.is_staff:
                return redirect('adminpanel')
            else:
                return redirect('home')

        else:
            return render(request, 'login.html', {'error': 'Invalid username or password'})

    return render(request, 'login.html')


# Register
def register(request):

    if request.method == 'POST':
        form = UserCreationForm(request.POST)

        if form.is_valid():
            form.save()
            return redirect('login')

    else:
        form = UserCreationForm()

    return render(request, 'register.html', {'form': form})

# User Profile

@login_required
def profile(request):

    user = request.user
    profile, created = UserProfile.objects.get_or_create(user=user)

    if request.method == 'POST':

        user.first_name = request.POST.get('first_name')
        user.email = request.POST.get('email')

        profile.phone = request.POST.get('phone')
        profile.address = request.POST.get('address')
        profile.city = request.POST.get('city')
        profile.state = request.POST.get('state') 

        if 'profile_image' in request.FILES:
            profile.profile_image = request.FILES['profile_image']

        user.save()
        profile.save()

        messages.success(request, "Profile Updated Successfully")

        return redirect('profile')

    return render(request,'profile.html',{'profile':profile})


def user_logout(request):
    logout(request)
    return redirect('home')


# Products Page
def products(request):
    categories = Category.objects.all()
    products = Product.objects.all()

    # 🔍 Search
    search_query = request.GET.get('search')
    if search_query:
        products = products.filter(name__icontains=search_query)

    # 📂 Category Filter
    category_id = request.GET.get('category')
    if category_id:
        products = products.filter(category_id=category_id)

    # ❤️ Wishlist
    wishlist_products = []
    if request.user.is_authenticated:
        wishlist, _ = Wishlist.objects.get_or_create(user=request.user)
        wishlist_items = WishlistItem.objects.filter(wishlist=wishlist)
        wishlist_products = [item.product for item in wishlist_items]

    return render(request, 'products.html', {
        'products': products,
        'categories': categories,
        'wishlist_products': wishlist_products
    })


# Product Details
def product_details(request, id):
    product = Product.objects.get(id=id)
    return render(request, 'product_details.html', {'product': product})


@login_required
def add_to_cart(request, product_id):

    if request.method == "POST":  

        product = get_object_or_404(Product, id=product_id)

        cart, created = Cart.objects.get_or_create(user=request.user)

        cart_item, created = CartItem.objects.get_or_create(
            cart=cart,
            product=product
        )

        if not created:
            if cart_item.quantity < product.stock:
                cart_item.quantity += 1
                cart_item.save()
            else:
                messages.warning(request, "Stock limit reached!")
        else:
            if product.stock == 0:
                messages.error(request, "Out of stock!")
                return redirect('products')

        messages.success(request, "Added to cart successfully!")

    return redirect(request.META.get('HTTP_REFERER', 'products'))


# Cart Page
@login_required
def cart(request):

    cart, created = Cart.objects.get_or_create(user=request.user)

    cart_items = CartItem.objects.filter(cart=cart)

    total_price = 0

    for item in cart_items:
        total_price += item.product.price * item.quantity

    context = {
        'cart_items': cart_items,
        'total_price': total_price
    }

    return render(request, 'cart.html', context)

@login_required
def remove_from_cart(request, item_id):

    item = get_object_or_404(CartItem, id=item_id)
    item.delete()

    return redirect('cart')

@login_required
def increase_quantity(request, item_id):
    item = get_object_or_404(CartItem, id=item_id)

    if item.quantity < item.product.stock:
        item.quantity += 1
        item.save()
    else:
        messages.warning(request, "Stock limit reached!")

    return redirect('cart')


@login_required
def decrease_quantity(request, item_id):
    item = get_object_or_404(CartItem, id=item_id)

    if item.quantity > 1:
        item.quantity -= 1
        item.save()
    else:
        item.delete()

    return redirect('cart')


# Checkout Page
@login_required
def checkout(request):
    cart, created = Cart.objects.get_or_create(user=request.user)
    cart_items = CartItem.objects.filter(cart=cart)

    total_price = sum(item.product.price * item.quantity for item in cart_items)

    if request.method == "POST":
        full_name = request.POST.get('full_name')
        address = request.POST.get('address')
        city = request.POST.get('city')
        pincode = request.POST.get('pincode')
        phone = request.POST.get('phone')

        # Create Order
        order = Order.objects.create(
            user=request.user,
            full_name=full_name,
            address=address,
            city=city,
            pincode=pincode,
            phone=phone,
            total_price=total_price
        )

        # Create Order Items
        for item in cart_items:
            OrderItem.objects.create(
                order=order,
                product=item.product,
                quantity=item.quantity,
                price=item.product.price
            )

        # Clear Cart
        cart_items.delete()

        messages.success(request, "Order placed successfully!")

        return redirect('order_success')

    return render(request, 'checkout.html', {
        'cart_items': cart_items,
        'total_price': total_price
    })


def order_success(request):
    return render(request, 'order_success.html')


@login_required
def my_orders(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')

    return render(request, 'my_orders.html', {
        'orders': orders
    })

@login_required
def order_detail_user(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    items = OrderItem.objects.filter(order=order)

    return render(request, 'order_detail_user.html', {
        'order': order,
        'items': items
    })

@login_required
def cancel_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)

    if order.status in ['Pending', 'Processing']:
        order.status = 'Cancelled'
        order.save()
        messages.success(request, "Order cancelled successfully!")
    else:
        messages.error(request, "Cannot cancel this order.")

    return redirect('my_orders')

# Categories Page

def categories(request):
    categories = Category.objects.all()  # Fetch all categories
    return render(request, 'categories.html', {'categories': categories})


@login_required
def toggle_wishlist(request, product_id):
    product = get_object_or_404(Product, id=product_id)

    wishlist, created = Wishlist.objects.get_or_create(user=request.user)

    item = WishlistItem.objects.filter(wishlist=wishlist, product=product)

    if item.exists():
        item.delete()
        messages.info(request, "Removed from wishlist")
    else:
        WishlistItem.objects.create(wishlist=wishlist, product=product)
        messages.success(request, "Added to wishlist ❤️")

    return redirect(request.META.get('HTTP_REFERER', 'products'))


@login_required
def wishlist_view(request):
    wishlist, _ = Wishlist.objects.get_or_create(user=request.user)

    items = WishlistItem.objects.filter(wishlist=wishlist).select_related('product')

    return render(request, 'wishlist.html', {'items': items})   



# Custom Admin Panel
@login_required
def adminpanel(request):

    if not request.user.is_staff:
        return redirect('home')

    total_orders = Order.objects.count()
    total_users = User.objects.count()
    total_products = Product.objects.count()
    total_revenue = sum(order.total_price for order in Order.objects.all())

    # Latest 5 orders
    recent_orders = Order.objects.select_related('user').order_by('-created_at')[:5]

    return render(request, 'adminpanel/adminpanel.html', {
        'total_orders': total_orders,
        'total_users': total_users,
        'total_products': total_products,
        'total_revenue': total_revenue,
        'recent_orders': recent_orders
    })




@login_required
def admin_products(request):

    if not request.user.is_staff:
        return redirect('home')

    products = Product.objects.all()

    return render(request, 'adminpanel/products.html', {'products': products})


@login_required
def add_product(request):

    if not request.user.is_staff:
        return redirect('home')

    categories = Category.objects.all()

    if request.method == "POST":

        name = request.POST['name']
        description = request.POST['description']
        price = request.POST['price']
        stock = request.POST['stock']
        category_id = request.POST['category']
        image = request.FILES['image']

        category = Category.objects.get(id=category_id)

        Product.objects.create(
            name=name,
            description=description,
            price=price,
            stock=stock,
            category=category,
            image=image
        )

        return redirect('admin_products')

    return render(request, 'adminpanel/add_product.html', {'categories': categories})


def edit_product(request, id):
    product = Product.objects.get(id=id)
    categories = Category.objects.all()

    if request.method == "POST":
        product.name = request.POST.get('name')
        product.price = request.POST.get('price')
        product.stock = request.POST.get('stock')
        product.description = request.POST.get('description')
        product.category_id = request.POST.get('category')

        if request.FILES.get('image'):
            product.image = request.FILES.get('image')

        product.save()
        return redirect('admin_products')

    return render(request, 'adminpanel/edit_product.html', {
        'product': product,
        'categories': categories
    })

def delete_product(request, id):
    product = Product.objects.get(id=id)
    product.delete()
    return redirect('admin_products')




def add_category(request):
    if request.method == "POST":
        name = request.POST.get('name')
        image = request.FILES.get('image')

        if name and image:
            Category.objects.create(
                name=name,
                image=image
            )
            return redirect('add_category')

    categories = Category.objects.all()
    return render(request, 'adminpanel/add_category.html', {
        'categories': categories
    })


def edit_category(request, id):
    category = Category.objects.get(id=id)

    if request.method == "POST":
        name = request.POST.get('name')
        image = request.FILES.get('image')

        if name:
            category.name = name

        if image:
            category.image = image

        category.save()
        return redirect('add_category')

    return render(request, 'adminpanel/edit_category.html', {
        'category': category
    })

def delete_category(request, id):
    category = Category.objects.get(id=id)
    category.delete()
    return redirect('add_category')


@login_required
def admin_orders(request):

    if not request.user.is_staff:
        return redirect('home')

    orders = Order.objects.all().order_by('-created_at')

    return render(request, 'adminpanel/orders.html', {
        'orders': orders
    })


@login_required
def admin_order_detail(request, order_id):

    if not request.user.is_staff:
        return redirect('home')

    order = get_object_or_404(Order, id=order_id)
    items = OrderItem.objects.filter(order=order)

    if request.method == "POST":
        new_status = request.POST.get('status')
        order.status = new_status
        order.save()

        messages.success(request, "Order status updated!")

    return render(request, 'adminpanel/order_detail.html', {
        'order': order,
        'items': items
    })


@login_required
def admin_users(request):

    if not request.user.is_staff:
        return redirect('home')

    users = User.objects.all()

    return render(request, 'adminpanel/users.html', {'users': users})



@login_required
def admin_customers(request):

    if not request.user.is_staff:
        return redirect('home')

    users = User.objects.filter(is_staff=False)

    customer_data = []

    for user in users:
        profile = UserProfile.objects.filter(user=user).first()
        orders = Order.objects.filter(user=user)

        total_orders = orders.count()
        total_spent = sum(order.total_price for order in orders)

        customer_data.append({
            'user': user,
            'profile': profile,
            'total_orders': total_orders,
            'total_spent': total_spent
        })

    return render(request, 'adminpanel/customers.html', {
        'customers': customer_data
    })


@login_required
def toggle_user_status(request, user_id):

    if not request.user.is_staff:
        return redirect('home')

    user = get_object_or_404(User, id=user_id)

    user.is_active = not user.is_active
    user.save()

    return redirect('admin_customers')  



from django.contrib.auth import update_session_auth_hash

@login_required
def admin_settings(request):

    if not request.user.is_staff:
        return redirect('home')

    if request.method == "POST":

        # 🔐 Change Password
        if 'change_password' in request.POST:
            current = request.POST.get('current_password')
            new = request.POST.get('new_password')

            if request.user.check_password(current):
                request.user.set_password(new)
                request.user.save()
                update_session_auth_hash(request, request.user)
                messages.success(request, "Password changed successfully!")
            else:
                messages.error(request, "Current password is incorrect!")

        # 🛠️ Maintenance Mode
        if 'maintenance' in request.POST:
            mode = request.POST.get('maintenance_mode')
            request.session['maintenance_mode'] = mode
            messages.success(request, "Maintenance mode updated!")

        # 🌙 Dark Mode
        if 'darkmode' in request.POST:
            mode = request.POST.get('dark_mode')
            request.session['dark_mode'] = mode
            messages.success(request, "Theme updated!")

    return render(request, 'adminpanel/settings.html')